insert into users values("Admin","iiiieee21");
insert into userss values("Phila","Ntombela","south africa");
